import sys
sys.path.append("../util/*")
sys.path.append("../db/*")
from util.Util import Util
from model.Vaccine import Vaccine
from db.ConnectionManager import ConnectionManager
import pymssql


class Appointment:
    def __init__(self, ID, pname, cname, vname, aptime):
        self.ID = ID
        self.pname = pname
        self.cname = cname
        self.vname = vname
        self.aptime = aptime


    def makeanappointment(self):
        cm = ConnectionManager()
        conn = cm.create_connection()
        cursor = conn.cursor()

        add_appointment = "INSERT INTO appointment VALUES "+ "(" + str(self.ID)+",'"+ str(self.pname)+"','"+str(self.cname)+"','"+str(self.vname)+"','"+str(self.aptime)+"')"
        #print(add_appointment)
        try:
            cursor.execute(add_appointment)
            # before committing the appointment, update the vaccine number first. If updating fails, the appointment wont commit.
            vaccine = Vaccine(self.vname,1).get()
            vaccine.decrease_available_doses(1)
            conn.commit()
        except pymssql.Error:
            print("Error occurred when making appointments")
            cm.close_connection()
        cm.close_connection()


