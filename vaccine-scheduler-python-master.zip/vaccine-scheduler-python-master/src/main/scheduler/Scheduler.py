import sys
from model.Vaccine import Vaccine
from model.Caregiver import Caregiver
from model.Patient import Patient
from model.Appointment import Appointment
from util.Util import Util
from db.ConnectionManager import ConnectionManager
import pymssql
import datetime


'''
objects to keep track of the currently logged-in user
Note: it is always true that at most one of currentCaregiver and currentPatient is not null
        since only one user can be logged-in at a time
'''
current_patient = None

current_caregiver = None


def create_patient(tokens):
    if len(tokens) != 3:
        print("Please try again!")
        return

    username = tokens[1]
    password = tokens[2]
    # check 2: check if the username has been taken already
    if username_exists_patient(username):
        print("Username taken, try again!")
        return

    salt = Util.generate_salt()
    hash = Util.generate_hash(password, salt)

    # create the patient
    try:
        patient = Patient(username, salt=salt, hash=hash)
        # save to patient information to our database
        try:
            patient.save_to_db()
        except:
            print("Create failed, Cannot save")
            return
        print(" *** Account created successfully *** ")
    except pymssql.Error:
        print("Create failed")
        return

def username_exists_patient(username):
    cm = ConnectionManager()
    conn = cm.create_connection()

    select_username = "SELECT * FROM Patients WHERE Username = %s"
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.execute(select_username, username)
        row = cursor.fetchone()
        if row is not None:
            return True
    except pymssql.Error:
        print("Error occurred when checking username")
        cm.close_connection()
    cm.close_connection()
    return False

def create_caregiver(tokens):
    # create_caregiver <username> <password>
    # check 1: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please try again!")
        return

    username = tokens[1]
    password = tokens[2]
    # check 2: check if the username has been taken already
    if username_exists_caregiver(username):
        print("Username taken, try again!")
        return

    salt = Util.generate_salt()
    hash = Util.generate_hash(password, salt)

    # create the caregiver
    try:
        caregiver = Caregiver(username, salt=salt, hash=hash)
        # save to caregiver information to our database
        try:
            caregiver.save_to_db()
        except:
            print("Create failed, Cannot save")
            return
        print(" *** Account created successfully *** ")
    except pymssql.Error:
        print("Create failed")
        return


def username_exists_caregiver(username):
    cm = ConnectionManager()
    conn = cm.create_connection()

    select_username = "SELECT * FROM Caregivers WHERE Username = %s"
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.execute(select_username, username)
        #  returns false if the cursor is not before the first record or if there are no rows in the ResultSet.
        for row in cursor:
            return row['Username'] is not None
    except pymssql.Error:
        print("Error occurred when checking username")
        cm.close_connection()
    cm.close_connection()
    return False


def login_patient(tokens):
    # check 1: if someone's already logged-in, they need to log out first
    global current_patient
    if current_patient is not None or current_caregiver is not None:
        print("Already logged-in!")
        return

    # check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please try again!")
        return

    username = tokens[1]
    password = tokens[2]

    # check 3: the username the patient tried to login exists. If not, ask to create one first.
    if not username_exists_patient(username):
        print("Patient username doesn't exist, please create an account first!")
        return

    patient = None
    try:
        try:
            patient = Patient(username, password=password).get()
        except:
            print("Get Failed")
            return
    except pymssql.Error:
        print("Error occurred when logging in")

    # check if the login was successful
    if patient is None:
        print("Please try again!")
    else:
        print("Patient logged in as: " + username)
        current_patient = patient

def login_caregiver(tokens):
    # login_caregiver <username> <password>
    # check 1: if someone's already logged-in, they need to log out first
    global current_caregiver
    if current_caregiver is not None or current_patient is not None:
        print("Already logged-in!")
        return

    # check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please try again!")
        return

    username = tokens[1]
    password = tokens[2]

    # check 3: the username the caregiver tried to login exists. If not, ask to create one first.
    if not username_exists_caregiver(username):
        print("Caregiver username doesn't exist, please create an account first!")
        return

    caregiver = None
    try:
        try:
            caregiver = Caregiver(username, password=password).get()
        except:
            print("Get Failed")
            return
    except pymssql.Error:
        print("Error occurred when logging in")

    # check if the login was successful
    if caregiver is None:
        print("Please try again!")
    else:
        print("Caregiver logged in as: " + username)
        current_caregiver = caregiver


def search_caregiver_schedule(tokens):

    if len(tokens) !=2:
        print("please try again!")
        return
    date=tokens[1]
    try:
        date_tokens = date.split("-")
        if len(date_tokens)!=3:
            print("Please enter the date in the required format: mm-dd-yyyy")
            return
        else:
            month = int(date_tokens[0])
            day = int(date_tokens[1])
            year = int(date_tokens[2])
            d = datetime.datetime(year, month, day)
    except ValueError:
        print("Please enter a valid date!")
        return

    cm = ConnectionManager()
    conn = cm.create_connection()

    select_availability = "SELECT Username, Time FROM Availabilities WHERE Time = %s"
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.execute(select_availability,date)
        row = cursor.fetchone()
        if row is None:
            print("No caregiver available on this date")
            return
        while row is not None:
            print(row)
            row = cursor.fetchone()
        checkvaccine('all')
    except pymssql.Error:
        print("Error occurred when checking schedule")
        cm.close_connection()
    cm.close_connection()

def checkvaccine(token):
    if token == 'all':
        select_vaccine2=""
    else:
        select_vaccine2= "WHERE Name = '" + str(token) +"'"
    cm = ConnectionManager()
    conn = cm.create_connection()

    select_vaccine = "SELECT * From Vaccines "
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.execute(select_vaccine+select_vaccine2)
        row = cursor.fetchone()
        if row is None:
            print("No dose available for "+ str(token))
            return 0
        totalvaccine = 0
        while row is not None:
            totalvaccine += row['Doses']
            if token == 'all':
                print(row)
            row = cursor.fetchone()
        if totalvaccine == 0:
            print("Unfortunately no available vaccine doses right now")
            return 0
        else:
            return totalvaccine
    except pymssql.Error:
        print("Error occurred when checking schedule")
        cm.close_connection()
    cm.close_connection()


def reserve(tokens):
    #  check 1: check if the current logged-in user is a patient
    global current_patient
    if current_patient is None:
        print("Please login as a patient first!")
        return
    # check 2: check if the entered string length is correct
    if len(tokens) !=3:
        print(len(tokens),"Please try again!")
        return
    # check 3: check if the datatime is in the right format
    date = tokens[1]
    try:
        date_tokens = date.split("-")
        if len(date_tokens) != 3:
            print("Please enter the date in the required format: mm-dd-yyyy")
            return
        else:
            month = int(date_tokens[0])
            day = int(date_tokens[1])
            year = int(date_tokens[2])
            d = datetime.datetime(year, month, day)
    except ValueError:
        print("Please enter a valid date!")
        return
    # check 4: the user has not make an appointment before
    cm = ConnectionManager()
    conn = cm.create_connection()
    try:
        patient_list="SELECT pname From appointment WHERE pname = " + "'"+str(current_patient.username)+"'"
        cursor = conn.cursor(as_dict=True)
        cursor.execute(patient_list)
        row = cursor.fetchone()
        if row is not None:
            print("You have already made an appointment!")
            return
    except pymssql.Error:
        print("Error occurred when checking username")
        cm.close_connection()
    cm.close_connection()

    vaccine_name=str(tokens[2])
    # Check vaccine availability
    vaccine_num=checkvaccine(vaccine_name)
    # Check caregiver availability
    caregiver_scheduled=check_caregiver_schedule(date)

    if (vaccine_num != 0) and (caregiver_scheduled != 0):
        # make an appointment and update the available vaccine number (func in Appointment.py)
        try:
            ID = get_ID()
            appointment=Appointment(ID,current_patient.username,caregiver_scheduled,vaccine_name,date)
            appointment.makeanappointment()
            print("You have successfully made an appointment with Caregiver: " + str(caregiver_scheduled))
            print("Your appointment ID is: " + str(ID))
        except pymssql.Error:
            print("Error occurred when making an appointment")

def get_ID():
    cm = ConnectionManager()
    conn = cm.create_connection()
    cursor = conn.cursor(as_dict=True)

    get_appointment_ID = "SELECT TOP 1 ID FROM appointment ORDER BY ID DESC"
    try:
        cursor.execute(get_appointment_ID)
        max_ID=1
        for row in cursor:
            #print(row['ID'])
            max_ID=row['ID']+1
        cm.close_connection()
        return max_ID
    except pymssql.Error:
        print("Error occurred when getting appointment ID")
    cm.close_connection()

def check_caregiver_schedule(tokens):

    date=tokens
    try:
        date_tokens = date.split("-")
        if len(date_tokens)!=3:
            print("Please enter the date in the required format: mm-dd-yyyy")
            return 0
        else:
            month = int(date_tokens[0])
            day = int(date_tokens[1])
            year = int(date_tokens[2])
            d = datetime.datetime(year, month, day)
    except ValueError:
        print("Please enter a valid date!")
        return 0

    cm = ConnectionManager()
    conn = cm.create_connection()

    select_availability = "SELECT Username, Time FROM Availabilities WHERE Time = %s"
    try:
        cursor = conn.cursor(as_dict=True)
        cursor.execute(select_availability,date)
        row = cursor.fetchone()
        if row is None:
            print("No caregiver available on this date")
            return 0
        avail_caregiver = None
        while row is not None:
            #print(row)
            avail_caregiver = row['Username']
            row = cursor.fetchone()
        cm.close_connection()
        return avail_caregiver
    except pymssql.Error:
        print("Error occurred when checking schedule")
        cm.close_connection()
        return 0


def upload_availability(tokens):
    #  upload_availability <date>
    #  check 1: check if the current logged-in user is a caregiver
    global current_caregiver
    if current_caregiver is None:
        print("Please login as a caregiver first!")
        return

    # check 2: the length for tokens need to be exactly 2 to include all information (with the operation name)
    if len(tokens) != 2:
        print("Please try again!")
        return

    date = tokens[1]
    # assume input is hyphenated in the format mm-dd-yyyy
    date_tokens = date.split("-")
    month = int(date_tokens[0])
    day = int(date_tokens[1])
    year = int(date_tokens[2])
    try:
        d = datetime.datetime(year, month, day)
        try:
            current_caregiver.upload_availability(d)
        except:
            print("Upload Availability Failed")
        print("Availability uploaded!")
    except ValueError:
        print("Please enter a valid date!")
    except pymssql.Error as db_err:
        print("Error occurred when uploading availability")


def cancel(tokens):

    if len(tokens)!=2:
        print("please try again")
        return

    global current_caregiver
    global current_patient
    ID=int(tokens[1])
    if (current_caregiver is None) and (current_patient is None):
        print("Please login first!")
        return
    elif current_patient is not None:
        cm = ConnectionManager()
        conn = cm.create_connection()
        check_appointment_p="SELECT * FROM appointment WHERE ID = " + str(ID) + "AND pname = '" + str(current_patient.username) + "'"
        cancel_appointment_patient = "DELETE FROM appointment WHERE ID = " + str(ID) + " AND pname = '" +str(current_patient.username) + "'"
        # print(cancel_appointment_patient)
        try:
            cursor = conn.cursor(as_dict=True)
            cursor.execute(check_appointment_p)
            row=cursor.fetchone()
            if row is None:
                print("You do not have this appointment")
                cm.close_connection()
            else:
                cursor2 = conn.cursor(as_dict=True)
                cursor2.execute(cancel_appointment_patient)
                conn.commit()
                # update vaccine number in the Vaccine table
                reserved_vaccine=Vaccine(row['vname'],1).get()
                reserved_vaccine.increase_available_doses(1)
                print("You have successfully canceled your appointment!")
        except pymssql.Error:
            print("Error occurred when canceling appointment")
            cm.close_connection()
        cm.close_connection()
    elif current_caregiver is not None:
        cm = ConnectionManager()
        conn = cm.create_connection()

        check_appointment_c="SELECT * FROM appointment WHERE ID = " + str(ID) + "AND cname = '" + str(current_caregiver.username) + "'"
        cancel_appointment_caregiver = "DELETE FROM appointment WHERE ID = " + str(ID) + " AND cname = '" +str(current_caregiver.username) + "'"
        try:
            cursor = conn.cursor(as_dict=True)
            cursor.execute(check_appointment_c)
            row = cursor.fetchone()
            if row is None:
                print("You do not have this appointment")
                cm.close_connection()
            else:
                cursor2 = conn.cursor(as_dict=True)
                cursor2.execute(cancel_appointment_caregiver)
                conn.commit()
                # update vaccine number in the Vaccine table
                reserved_vaccine = Vaccine(row['vname'], 1).get()
                reserved_vaccine.increase_available_doses(1)
                print("You have successfully canceled your appointment!")
        except pymssql.Error:
            print("Error occurred when showing appointment")
            cm.close_connection()
        cm.close_connection()
# need to update vaccine numbers


def add_doses(tokens):
    #  add_doses <vaccine> <number>
    #  check 1: check if the current logged-in user is a caregiver
    global current_caregiver
    if current_caregiver is None:
        print("Please login as a caregiver first!")
        return

    #  check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
    if len(tokens) != 3:
        print("Please try again!")
        return

    vaccine_name = str(tokens[1])
    doses = int(tokens[2])
    vaccine = None
    try:
        try:
            vaccine = Vaccine(vaccine_name, doses).get()
        except:
            print("Failed to get Vaccine!")
            return
    except pymssql.Error:
        print("Error occurred when adding doses")

    # check 3: if getter returns null, it means that we need to create the vaccine and insert it into the Vaccines
    #          table

    if vaccine is None:
        try:
            vaccine = Vaccine(vaccine_name, doses)
            try:
                vaccine.save_to_db()
            except:
                print("Failed To Save")
                return
        except pymssql.Error:
            print("Error occurred when adding doses")
    else:
        # if the vaccine is not null, meaning that the vaccine already exists in our table
        try:
            try:
                vaccine.increase_available_doses(doses)
            except:
                print("Failed to increase available doses!")
                return
        except pymssql.Error:
            print("Error occurred when adding doses")

    print("Doses updated!")


def show_appointments(tokens):
    global current_caregiver
    global current_patient
    if (current_caregiver is None) and (current_patient is None):
        print("Please login first!")
        return
    elif current_patient is not None:
        cm = ConnectionManager()
        conn = cm.create_connection()

        show_appointment_patient = "SELECT ID, vname, aptime, cname FROM appointment WHERE pname = '" + str(current_patient.username)+"'"
        #print(show_appointment_patient)
        try:
            cursor = conn.cursor(as_dict=True)
            cursor.execute(show_appointment_patient)
            row = cursor.fetchone()
            if row is None:
                print("You do not have any appointment yet.")
            while row is not None:
                print(row)
                row=cursor.fetchone()
        except pymssql.Error:
            print("Error occurred when showing appointment")
            cm.close_connection()
        cm.close_connection()

    elif current_caregiver is not None:
        cm = ConnectionManager()
        conn = cm.create_connection()

        show_appointment_caregiver = "SELECT ID, vname, aptime, pname FROM appointment WHERE cname = '" + str(
            current_caregiver.username) + "'"
        #print(show_appointment_caregiver)
        try:
            cursor = conn.cursor(as_dict=True)
            cursor.execute(show_appointment_caregiver)
            row = cursor.fetchone()
            if row is None:
                print("You do not have any appointment yet.")
            while row is not None:
                print(row)
                row = cursor.fetchone()
        except pymssql.Error:
            print("Error occurred when showing appointment")
            cm.close_connection()
        cm.close_connection()

def logout(tokens):
    global current_caregiver
    global current_patient
    try:
        current_patient = None
        current_caregiver = None
        print("You have successfully logged out!")
    except:
        print("Error occur when logging out")



def start():
    stop = False
    while not stop:
        print()
        print(" *** Please enter one of the following commands *** ")
        print("> create_patient <username> <password>")  # //TODO: implement create_patient (Part 1)
        print("> create_caregiver <username> <password>")
        print("> login_patient <username> <password>")  #// TODO: implement login_patient (Part 1)
        print("> login_caregiver <username> <password>")
        print("> search_caregiver_schedule <date>")  #// TODO: implement search_caregiver_schedule (Part 2)
        print("> reserve <date> <vaccine>") #// TODO: implement reserve (Part 2)
        print("> upload_availability <date>")
        print("> cancel <appointment_id>") #// TODO: implement cancel (extra credit)
        print("> add_doses <vaccine> <number>")
        print("> show_appointments")  #// TODO: implement show_appointments (Part 2)
        print("> logout") #// TODO: implement logout (Part 2)
        print("> Quit")
        print()
        response = ""
        print("> Enter: ", end='')

        try:
            response = str(input())
        except ValueError:
            print("Type in a valid argument")
            break

        response = response.lower()
        tokens = response.split(" ")
        if len(tokens) == 0:
            ValueError("Try Again")
            continue
        operation = tokens[0]
        if operation == "create_patient":
            create_patient(tokens)
        elif operation == "create_caregiver":
            create_caregiver(tokens)
        elif operation == "login_patient":
            login_patient(tokens)
        elif operation == "login_caregiver":
            login_caregiver(tokens)
        elif operation == "search_caregiver_schedule":
            search_caregiver_schedule(tokens)
        elif operation == "reserve":
            reserve(tokens)
        elif operation == "upload_availability":
            upload_availability(tokens)
        elif operation == "cancel":
            cancel(tokens)
        elif operation == "add_doses":
            add_doses(tokens)
        elif operation == "show_appointments":
            show_appointments(tokens)
        elif operation == "logout":
            logout(tokens)
        elif operation == "quit":
            print("Thank you for using the scheduler, Goodbye!")
            stop = True
        else:
            print("Invalid Argument")


if __name__ == "__main__":
    '''
    // pre-define the three types of authorized vaccines
    // note: it's a poor practice to hard-code these values, but we will do this ]
    // for the simplicity of this assignment
    // and then construct a map of vaccineName -> vaccineObject
    '''

    # start command line
    print()
    print("Welcome to the COVID-19 Vaccine Reservation Scheduling Application!")

    start()