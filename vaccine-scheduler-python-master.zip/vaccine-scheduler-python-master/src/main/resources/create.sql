CREATE TABLE Caregivers (
    Username varchar(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (Username)
);

CREATE TABLE Availabilities (
    Time date,
    Username varchar(255) REFERENCES Caregivers,
    PRIMARY KEY (Time, Username)
);

CREATE TABLE Vaccines (
    Name varchar(255),
    Doses int,
    PRIMARY KEY (Name)
);

CREATE TABLE Patients (
    username varchar(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (Username)
);

CREATE TABLE appointment (
    ID int,
    pname varchar(255) REFERENCES Patients,
    cname varchar(255) REFERENCES Caregivers,
    vname varchar(255) REFERENCES Vaccines,
    aptime DATE,
    FOREIGN KEY (aptime, cname) REFERENCES Availabilities,
    PRIMARY KEY (ID)
);